<?php $__env->startSection('content'); ?>

    <div id="fb-root"></div>
    <script>(function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.6";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

    <div class="container">
        <section class="book-info">
            <article>
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <h3><?php echo e($book->name); ?></h3>
                        <?php foreach($book->authors as $author): ?>
                            <p>Tác giả: <?php echo e($author->name); ?></p>
                        <?php endforeach; ?>
                    </div>
                    <div class="col-sm-3">
                        <img class="img-responsive" src="<?php echo e($book->image_url); ?>" alt="<?php echo e($book->name); ?>">
                    </div>
                    <div class="col-sm-9">
                        <p><?php echo $book->description; ?></p>
                    </div>
                </div>

            </article>
        </section>
        <br>
        <section class="chapters">
            <h4>Danh sách chương:</h4>
            <div class="row">
                <?php foreach($chapters as $chapter): ?>
                    <div class="col-sm-6">
                        <a href="/<?php echo e($book->slug); ?>/<?php echo e($chapter->slug_chapter); ?>"><?php echo e($chapter->title); ?></a>
                    </div>

                <?php endforeach; ?>
            </div>
            <div class="row text-center">
                <?php echo e($chapters->render()); ?>

            </div>
        </section>
        <br>
        <section>
            <div class="row">
                <div class="col-md-6">
                    <div class="fb-comments" data-href="http://truyennet.dev/<?php echo e($book->slug); ?>" data data-numposts="10"></div>
                </div>
                <div class="col-md-6">
                    <b>Truyện cùng tác giả</b>
                    <hr>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tr>
                                <th>Tên truyện</th>
                                <th>Thể loại</th>
                                <th>Số chương</th>
                            </tr>
                            <?php foreach($authors as $author): ?>
                                <?php foreach($author->books as $book): ?>
                                    <tr>
                                        <td><a href="/<?php echo e($book->slug); ?>"><?php echo e($book->name); ?></a></td>
                                        <td>
                                            <?php foreach($book->categories as $category): ?>
                                                <a href="/the-loai/<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></a>
                                                <?php echo e(semi_value($book->categories->last()->name, $category->name)); ?>

                                            <?php endforeach; ?>
                                        </td>
                                        <td><a href="/<?php echo e($book->slug); ?>/chuong-<?php echo e($book->chapters()->max('ordinal')); ?>">Chương <?php echo e($book->chapters()->max('ordinal')); ?></a></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </table>
                    </div>

                </div>
            </div>
        </section>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>