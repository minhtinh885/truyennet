<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row page-title-row">
			<div class="col-md-6">
				<h3 class="pull-left">Quản lý tập tin&nbsp;&nbsp;</h3>
				<div class="pull-left">
					<ul class="breadcrumb">
						<?php foreach($breadcrumbs as $path => $disp): ?>
							<li><a href="/admin/upload?folder=<?php echo e($path); ?>"><?php echo e($disp); ?></a></li>
						<?php endforeach; ?>
						<li class="active"><?php echo e($folderName); ?></li>
					</ul>
				</div>
			</div>
			<div class="col-md-6 text-right">
				<button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#modal-folder-create">
					<i class="fa fa-plus-circle"></i> Tạo Mới Thư Mục
				</button>
				<button type="button" class="btn btn-primary btn-md" data-toggle="modal" data-target="#modal-file-upload">
					<i class="fa fa-upload"></i> Tải Lên
				</button>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('admin.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<table id="uploads-table" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>Tên</th>
							<th>Loại</th>
							<th>Ngày</th>
							<th>Kích cỡ</th>
							<th data-sortable="false">Chức năng</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($subfolders as $path => $name): ?>
							<tr>
								<td><a href="/admin/upload?folder=<?php echo e($path); ?>">
									<i class="fa fa-folder fa-lg fa-lw"></i>
										<?php echo e($name); ?>

									</a>
								</td>
								<td>Thư mục</td>
								<td>-</td>
								<td>-</td>
								<td>
									<button type="button" class="btn btn-xs btn-danger" onclick="delete_folder('<?php echo e($name); ?>')">
										<i class="fa fa-times-circle fa-lg"></i>Xóa
									</button>
								</td>
							</tr>
						<?php endforeach; ?>

						<?php foreach($files as $file): ?>
							<tr>
								<td>
									<a href="<?php echo e($file['webPath']); ?>">
										<?php if(is_image($file['mimeType'])): ?>
											<i class="fa fa-file-image-o fa-lg fa-fw"></i>
										<?php else: ?>
											<i class="fa fa-file-o fa-lg fa-fw"></i>
										<?php endif; ?>
										<?php echo e($file['name']); ?>

									</a>
								</td>
								<td><?php echo e(isset($file['mimeType']) ? $file['mimeType'] : 'Unknown'); ?></td>
								<td><?php echo e($file['modified']->format('j-M-Y g:ia')); ?></td>
								<td><?php echo e(human_filesize($file['size'])); ?></td>
								<td>
									<button type="button" class="btn btn-xs btn-danger" onclick="delete_file('<?php echo e($file['name']); ?>')">
										<i class="fa fa-times-circle fa-lg"></i> Xóa
									</button>
									<?php if(is_image($file['mimeType'])): ?>
										<button type="button" class="btn btn-xs btn-success" onclick="preview_image('<?php echo e($file['webPath']); ?>')">
											<i class="fa fa-eye fa-lg"></i> Xem
										</button>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<?php echo $__env->make('admin.upload._modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js" type="text/javascript"></script>
	<script type="text/javascript">
		// Confirm file delete
		function delete_file(name)
		{
			$("#delete-file-name1").html(name);
			$("#delete-file-name2").val(name);
			$("#modal-file-delete").modal("show");
		}

		// Confirm folder delete
		function delete_folder(name)
		{
			$("#delete-folder-name1").html(name);
			$("#delete-folder-name2").val(name);
			$("#modal-folder-delete").modal("show");
		}

		// Preview image
		function preview_image(path)
		{
			$("#preview-image").attr("src", path);
			$("#modal-image-view").modal("show");
		}

		// Startup code

		$(document).ready(function(){
	    	$('#uploads-table').DataTable();
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>