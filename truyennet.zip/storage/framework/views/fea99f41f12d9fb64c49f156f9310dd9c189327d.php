<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row page-title-row">
		<div class="col-md-6">
			<h3>Thể loại truyện<small>&raquo; Danh sách</small></h3>
		</div>
		<div class="col-md-6 text-right">
			<a href="/admin/category/create" class="btn btn-success btn-md"><i class="fa fa-plus-circle"></i> Tạo mới một thể loại</a>
			
		</div>
	</div>

	<div class="row">
		<div class="col-sm-12">
			<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('admin.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<table class="table table-striped table-bordered">
				<caption><h5>Trang <?php echo e($categories->currentPage()); ?> trên <?php echo e($categories->lastPage()); ?></h5></caption>
				<thead>
					<tr>
						<th>Tên</th>
						<th>Slug</th>
						<th>Hành động</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($categories as $category): ?>
						<tr>
							<td><?php echo e($category->name); ?></td>
							<td><?php echo e($category->slug); ?></td>
							<td>
								<a href="/admin/category/<?php echo e($category->id); ?>/edit" class="btn btn-xs btn-info"><i class="fa fa-edit"></i> Edit</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php echo $categories->links(); ?>


		</div>
		
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>