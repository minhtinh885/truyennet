<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row page-title-row">
		<div class="col-md-6">
			<h3>Sách (<?php echo e($book->name); ?>)<small>&raquo; Danh sách</small></h3>
		</div>
		<div class="col-md-6 text-right">
			<a href="/admin/<?php echo e($book->slug); ?>/create" class="btn btn-success btn-md"><i class="fa fa-plus-circle"></i> Tạo mới một chương</a>
			
		</div>
	</div>

	<div class="row">
		<div class="col-sm-12">
			<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('admin.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<table class="table table-striped table-bordered">
				<caption><h5>Trang <?php echo e($chapters->currentPage()); ?> trên <?php echo e($chapters->lastPage()); ?></h5></caption>
				<thead>
					<tr>
						<th>Thứ tự</th>
						<th>Tiêu đề</th>
						<th>Slug</th>
						<th>Ngày đăng</th>
						<th>Hành động</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($chapters as $chapter): ?>
						<tr>
							<td><?php echo e($chapter->ordinal); ?></td>
							<td><?php echo e($chapter->title); ?></td>
							<td><?php echo e($chapter->slug_chapter); ?></td>
							<td><?php echo e($chapter->published_at); ?></td>
							<td>
								<a href="/admin/chapter/<?php echo e($chapter->id); ?>/edit" class="btn btn-xs btn-info"><i class="fa fa-edit"></i> Sửa</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php echo $chapters->links(); ?>


		</div>
		
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>