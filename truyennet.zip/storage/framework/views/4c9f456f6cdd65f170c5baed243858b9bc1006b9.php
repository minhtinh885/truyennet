<?php $__env->startSection('content'); ?>
    <div class="container">
        <section>
            <div class="row">
                <div class="col-xs-12 text-center">
                    <h2><?php echo e($category->name); ?></h2>
                    <br>
                </div>
                <div class="col-xs-12">
                    <h3>Danh sách truyện</h3>
                    <br>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tr>
                                <th>Tên truyện</th>
                                <th>Thể loại</th>
                                <th>Số chương</th>
                            </tr>
                            <?php foreach($books as $book): ?>
                                <tr>
                                    <td><a href="/<?php echo e($book->slug); ?>"><?php echo e($book->name); ?></a></td>
                                    <td>
                                        <?php foreach($book->categories as $category): ?>
                                            <a href="/the-loai/<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></a>
                                            <?php echo e(semi_value($book->categories->last()->name, $category->name)); ?>

                                        <?php endforeach; ?>
                                    </td>
                                    <td><a href="/<?php echo e($book->slug); ?>/chuong-<?php echo e($book->chapters()->max('ordinal')); ?>">Chương <?php echo e($book->chapters()->max('ordinal')); ?></a></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row text-center">
                <?php echo e($books->render()); ?>

            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>