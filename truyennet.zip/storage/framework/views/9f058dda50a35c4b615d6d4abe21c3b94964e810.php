<?php if(count($errors)>0): ?>
	<div class="alert alert-danger">
		<strong>Whoops!</strong>
		Có một vài lỗi đã xảy ra.<br><hr>
		<ul>
			<?php foreach($errors->all() as $error): ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
<?php endif; ?>