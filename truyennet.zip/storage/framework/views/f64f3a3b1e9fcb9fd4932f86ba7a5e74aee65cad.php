<?php if(Session::has('success')): ?>
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">&times;</button>
		<strong>
			<i class="fa fa-check-circle fa-lg fa-fw"></i> Thành công. &nbsp;
		</strong>
		<?php echo e(Session::get('success')); ?>

	</div>
<?php endif; ?>