<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row page-title-row">
		<div class="col-md-6">
			<h3>Tác giả<small>&raquo; Danh sách</small></h3>
		</div>
		<div class="col-md-6 text-right">
			<a href="/admin/author/create" class="btn btn-success btn-md"><i class="fa fa-plus-circle"></i> Tạo mới một tác giả</a>
			
		</div>
	</div>

	<div class="row">
		<div class="col-sm-12">
			<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('admin.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<table class="table table-striped table-bordered">
				<caption><h5>Trang <?php echo e($authors->currentPage()); ?> trên <?php echo e($authors->lastPage()); ?></h5></caption>
				<thead>
					<tr>
						<th>Tên</th>
						<th>Slug</th>
						<th>Mô tả</th>
						<th>Hành động</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($authors as $author): ?>
						<tr>
							<td><?php echo e($author->name); ?></td>
							<td><?php echo e($author->slug); ?></td>
							<td><?php echo e($author->description); ?></td>
							<td>
								<a href="/admin/author/<?php echo e($author->id); ?>/edit" class="btn btn-xs btn-info"><i class="fa fa-edit"></i> Edit</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php echo $authors->links(); ?>


		</div>
		
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>