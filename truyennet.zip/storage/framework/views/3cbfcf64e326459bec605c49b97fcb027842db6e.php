<div class="form-group">
    <label for="slug" class="col-md-3 control-label">Link</label>
    <div class="col-md-3">
        <input type="text" class="form-control" name="slug" value="<?php echo e($slug); ?>" autofocus>
    </div>
</div>

<div class="form-group">
    <label for="using" class="col-md-3 control-label">Đã sử dụng</label>
    <div class="col-md-3">
        <input type="checkbox" class="checkbox" name="using" <?php if($using): ?> checked <?php endif; ?>>
    </div>
</div>

<div class="form-group">
    <label for="limit" class="col-md-3 control-label">Số chương</label>
    <div class="col-md-3">
        <input type="number" class="form-control" name="limit" value="<?php echo e($limit); ?>">
    </div>
</div>