<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row page-title-row">
		<div class="col-md-6">
			<h3>Sách<small>&raquo; Danh sách</small></h3>
		</div>
		<div class="col-md-6 text-right">
			<a href="/admin/book/create" class="btn btn-success btn-md"><i class="fa fa-plus-circle"></i> Tạo mới một quyển truyện</a>
			
		</div>
	</div>

	<div class="row">
		<div class="col-sm-12">
			<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('admin.partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<table class="table table-striped table-bordered">
				<caption><h5>Trang <?php echo e($books->currentPage()); ?> trên <?php echo e($books->lastPage()); ?></h5></caption>
				<thead>
					<tr>
						<th>Tên</th>
						<th>Slug</th>
						<th>Mô tả</th>
						<th>Hình ảnh</th>
						<th>Nguồn</th>
						<th>Trạng thái</th>
						<th>Đánh giá</th>
						<th>Hành động</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($books as $book): ?>
						<tr>
							<td><?php echo e($book->name); ?></td>
							<td><?php echo e($book->slug); ?></td>
							<td><?php if(strlen($book->description) > 30): ?><?php echo e(substr($book->description, 0, 30)); ?>... <?php else: ?> <?php echo e($book->description); ?> <?php endif; ?></td>
							<td><?php echo e($book->image_url); ?></td>
							<td><?php echo e($book->source_from); ?></td>
							<td><?php echo e($book->status); ?></td>
							<td><?php echo e($book->review); ?></td>
							<td>
								<a href="/admin/book/<?php echo e($book->id); ?>/edit" class="btn btn-xs btn-info"><i class="fa fa-edit"></i> Sửa</a>
								<a href="/admin/<?php echo e($book->slug); ?>/chapter-all" class="btn btn-xs btn-success"><i class="fa fa-book"></i> Xem ds</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php echo $books->links(); ?>


		</div>
		
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>