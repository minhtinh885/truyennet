<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\CrawlTitle;
use Illuminate\Support\Facades\Auth;


class AutoCrawlController extends Controller
{
    public function index(){
        $crawlerTitles = CrawlTitle::orderBy('updated_at', 'DESC')->paginate(50);
        return view('admin.crawlers.index', compact('crawlerTitles'));
    }
    
    public function create()
    {
        $slug = old('slug', 'http://');
        $using = old('using', '0');
        $limit = old('using', '1');
        return view('admin.crawlers.create', ['slug' => $slug, 'using' => $using, 'limit' => $limit]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'slug' => 'required|unique:crawl_title,slug',
//            'using' => 'required',
            'limit' => 'required',
        ]);
        $crawlerTitle = new CrawlTitle();
        $crawlerTitle->slug = $request->get('slug');
        $crawlerTitle->using = $request->get('using')?1:0;
        $crawlerTitle->limit = $request->get('limit');

        $crawlerTitle->save();
        return redirect('admin/auto-crawl')->withSuccess("Đường dẫn '$crawlerTitle->slug' đã được tạo thành công !");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $crawlerTitle = CrawlTitle::findOrFail($id);
        $data = ['id' => $id];
        $data['slug'] = old('slug', $crawlerTitle->slug);
        $data['using'] = old('using', $crawlerTitle->using);
        $data['limit'] = old('limit', $crawlerTitle->limit);

        return view('admin.crawlers.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'slug' => 'required',
//            'using' => 'required',
            'limit' => 'required',
        ]);
        $crawlerTitle = CrawlTitle::findOrFail($id);
        $crawlerTitle->slug = $request->get('slug');
        $crawlerTitle->using = $request->get('using')=='on'?1:0;
        $crawlerTitle->limit = $request->get('limit');

        $crawlerTitle->save();
        return redirect("/admin/auto-crawl/$id/edit")->withSuccess("Đã lưu thay đổi.");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $crawlerTitle = CrawlTitle::findOrFail($id);
        $crawlerTitle->delete();

        return redirect('/admin/auto-crawl')->withSuccess("Đường dẫn '$crawlerTitle->slug' đã được xóa.");
    }
}
