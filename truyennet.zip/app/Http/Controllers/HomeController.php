<?php

namespace App\Http\Controllers;

use App\Author;
use App\Book;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Category;
use App\Chapter;
use Carbon\Carbon;
use PhpParser\Node\Expr\Array_;
use PhpParser\Node\Expr\Cast\Object_;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::orderBy('name', 'ASC')->select(['slug', 'name'])->get();
        $allBooks = Book::where('published_at', '<=',Carbon::now())->orderBy('review', 'DESC')->take(23);
        $top = $allBooks->take(1)->get();
        $topBooks = $allBooks->skip(1)->take(12)->get();
        $books = $allBooks->with('categories')->skip(13)->take(10)->get();
        return view('app.index', compact(['categories', 'top', 'topBooks', 'books']));
    }

    public function show($book_slug)
    {
        $categories = Category::orderBy('name', 'ASC')->select(['slug', 'name'])->get();
        $book = Book::whereSlug($book_slug)->first();
        $chapters = $book->chapters()->where('published_at', '<=',Carbon::now())->orderBy('ordinal', 'ASC')->paginate(50);
        $breadScrumbs = [];
        $authors = $book->authors()->get();
        array_push($breadScrumbs, [$book_slug, $book->name]);
        $title = $book->name;
        return view('app.show', compact(['book', 'categories', 'chapters','authors','breadScrumbs', 'title']));
    }

    public function chapter($book_slug, $chapter_slug)
    {
        $categories = Category::orderBy('name', 'ASC')->select(['slug', 'name'])->get();

        $book = Book::whereSlug($book_slug)->select(['id', 'slug', 'name'])->first();
        $book_id = $book->id;
        $chapter = Chapter::where('book_id', $book_id)->where('slug_chapter', $chapter_slug)->where('published_at', '<=',Carbon::now())->first();
        $prev = null;
        $next = null;
        $prevChapter =  Chapter::where('book_id', $book_id)->where('slug_chapter', 'chuong-'.($chapter->ordinal - 1))->where('published_at', '<=',Carbon::now())->first();
        $nextChapter =  Chapter::where('book_id', $book_id)->where('slug_chapter', 'chuong-'.($chapter->ordinal + 1))->where('published_at', '<=',Carbon::now())->first();
        if($prevChapter){
            $prev = 'chuong-' . ($chapter->ordinal - 1);
        }
        if($nextChapter){
            $next = 'chuong-' . ($chapter->ordinal + 1);
        }
        $breadScrumbs = [];
        array_push($breadScrumbs, [$book_slug, $book->name]);
        array_push($breadScrumbs, [$book_slug.'/'.$chapter_slug, $chapter->title]);
        $title = $book->name . ' - ' . $chapter->title;
        return view('app.chapter', compact(['chapter', 'prev', 'next', 'categories', 'breadScrumbs', 'book', 'title']));
    }
    public function category($category_slug)
    {
        $categories = Category::orderBy('name', 'ASC')->select(['slug', 'name'])->get();

        $category = Category::whereSlug($category_slug)->first();
        $books = $category->books()->orderBy('name', 'ASC')->paginate(50);
        $breadScrumbs = [];
        array_push($breadScrumbs, [$category_slug, $category->name]);
        $title = 'Truyện ' . $category->name;
        return view('app.category', compact(['books','category', 'categories', 'breadScrumbs', 'title']));
    }

    public function listOption($list_slug)
    {
        $listOptions = ['truyen-moi'=> 'Truyện mới cập nhật', 'truyen-hot'=>'Truyện Hot', 'truyen-hoan-thanh'=> 'Truyện hoàn thành'];
        $categories = Category::orderBy('name', 'ASC')->select(['slug', 'name'])->get();
        $breadScrumbs = [];
        $caption = '';
        if($list_slug == 'truyen-moi'){
            $books = Book::where('published_at', '<=', Carbon::now())->orderBy('updated_at', 'DESC')->paginate(50);
            $caption = $listOptions[$list_slug];
            array_push($breadScrumbs, [$list_slug, $listOptions[$list_slug]]);
            $title = 'Danh sách truyện mới';
        }
        if($list_slug == 'truyen-hot'){
            $books = Book::where('published_at', '<=', Carbon::now())->orderBy('review', 'DESC')->paginate(50);
            $caption = $listOptions[$list_slug];
            array_push($breadScrumbs, [$list_slug, $listOptions[$list_slug]]);
            $title = 'Danh sách truyện hot';
        }
        if($list_slug == 'truyen-hoan-thanh'){
            $books = Book::where('published_at', '<=', Carbon::now())->whereStatus('Đã hoàn thành')->orderBy('name', 'DESC')->paginate(50);
            $caption = $listOptions[$list_slug];
            array_push($breadScrumbs, [$list_slug, $listOptions[$list_slug]]);
            $title = 'Danh sách truyện đã hoàn thành';
        }
        if(isset($books)){
            return view('app.list', compact(['books', 'categories', 'breadScrumbs', 'caption', 'title']));
        }
        return redirect('/home')->withErrors('Không tồn tại đường link dẫn đến '.$list_slug);
    }

    public function search()
    {
        $search = \Request::get('tu-khoa');
        $books = Book::where('name', 'like', '%'.$search.'%')->orderBy('name', 'ASC')->paginate(10);
        $categories = Category::orderBy('name', 'ASC')->select(['slug', 'name'])->get();
        $breadScrumbs = [];
        array_push($breadScrumbs, ['tim-kiem', 'Tìm kiếm']);
        array_push($breadScrumbs, ['tu-khoa', $search]);
        $title = 'Tìm truyện với từ khóa: ' . $search;
        return view('app.search', compact(['books', 'categories', 'breadScrumbs', 'title']));
    }
}
