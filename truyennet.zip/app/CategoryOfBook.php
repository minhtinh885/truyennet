<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryOfBook extends Model
{
    //
}
