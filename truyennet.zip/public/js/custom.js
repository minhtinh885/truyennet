$('.dropdown-menu').click(function (e) {
    e.stopPropagation();
});
$('document').ready(function () {
    var customize_info = {};
    if(localStorage.getItem('customize_info')){
        customize_info = JSON.parse(localStorage.getItem('customize_info'));
        $("#body-id").css('background', customize_info['bg_color']);
        $("#bg-id").val(customize_info['bg_color']);

        if(customize_info['bg_color'] == '#232323') {
            $('#container-chapter').css('color', '#ebebeb');
        }else{
            $('#container-chapter').css('color','#3b3b3b');
        }

        $('#chapter-content').css('font-family',customize_info['font_family']);
        $('#font-id').val(customize_info['font_family']);

        $('#chapter-content').css('font-size',customize_info['font_size']);
        $('#size-id').val(customize_info['font_size']);
        $('#chapter-content').css('line-height',customize_info['line_height']);
        $('#height-id').val(customize_info['line_height']);
        if(customize_info['fluid_switch'] == 'fluid'){
            $("#container-chapter").removeClass("container");
            $("#container-chapter").addClass("container-fluid");
            $('#fluid-bg').prop('checked', true);
        }else{
            $("#container-chapter").removeClass("container-fluid");
            $("#container-chapter").addClass("container");
            $('#no-fluid-bg').prop('checked', true);
        }

    }

    var currentChapterText = $("#chap-name").text();
    var currentChapterSlug = $("#chap-slug").text();
    var currentBookText = $("#book-name").text();
    var currentBookSlug = $("#book-slug").text();
    var local_info = {};
    if(localStorage.getItem('local_info')){
        local_info = JSON.parse(localStorage.getItem('local_info'));
    }
    local_info[currentBookSlug]= {
        'bookName' : currentBookText,
        'bookSlug' : currentBookSlug,
        'bookUrl' : '<a href="/' + currentBookSlug + '">' + currentBookText + '</a>',

        'chapterName' : currentChapterText,
        'chapterSlug': currentChapterSlug,
        'chapterUrl' : '<a href="/' + currentBookSlug + '/' + currentChapterSlug + '">' + currentChapterText + '</a>'
    }
    localStorage.setItem('local_info', JSON.stringify(local_info));
});

function customize(){
    var customize_info = {};
    if(localStorage.getItem('customize_info')){
        customize_info = JSON.parse(localStorage.getItem('customize_info'));
    }
    customize_info= {
        'bg_color' : $("#bg-id").val(),
        'font_family' : $('#font-id').val(),
        'font_size' : $('#size-id').val(),

        'line_height' : $('#height-id').val(),
        'fluid_switch': $('input:radio[name="fluid-switch"]:checked').val()
    }
    localStorage.setItem('customize_info', JSON.stringify(customize_info));

    $("#body-id").css('background', customize_info['bg_color']);

    if(customize_info['bg_color'] == '#232323') {
        console.log('true');
        $('#container-chapter').css('color', '#ebebeb');
    }else{
        $('#container-chapter').css('color','#3b3b3b');
        console.log("false");
    }

    $('#chapter-content').css('font-family',customize_info['font_family']);
    $('#chapter-content').css('font-size',customize_info['font_size']);
    $('#chapter-content').css('line-height',customize_info['line_height']);
    if(customize_info['fluid_switch'] == 'fluid'){
        $("#container-chapter").removeClass("container");
        $("#container-chapter").addClass("container-fluid");
    }else{
        $("#container-chapter").removeClass("container-fluid");
        $("#container-chapter").addClass("container");
    }
}
