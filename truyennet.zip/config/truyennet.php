
<?php
return [
	'title' => 'TruyenNet',
	'book_per_page' => '50',
	'page_image' => '',
	'uploads' => [
		'storage' => 'local',
		'webpath' => '/uploads',
	],
];