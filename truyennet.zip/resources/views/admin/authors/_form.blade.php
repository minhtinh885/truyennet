<div class="form-group">
    <label for="description" class="col-md-2 control-label">
        Mô tả
    </label>
    <div class="col-md-10">
        <textarea class="form-control" name="description" rows="15" id="content">{{$description}}</textarea>
    </div>
</div>